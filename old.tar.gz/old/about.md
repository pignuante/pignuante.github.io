---
title: About
permalink: /about/
---
![profile]({{ site.url }}/assets/images/profile.jpeg)



#### Pignu Ante
- Architecture/Business Administration/Computer Science & Engineering
- C/C++/Python/R/Linux/Java/Lisp/OS/Algorithm/Data Science/
  - Pragramming Language
  - Introduction to Computer & Lab
  - Computer Programming & Lab
  - Computer System Design
  - Logic Ciruit & Lab
  - Data Structure
  - PC HardWare
  - Design & Analysis of Algorithm
  - Compiler Construction
  - Assembly & Lab
  - Computer Architectrue & Lab
  - Data Base
  - Big Data Analysis
  - Database Design
  - System Programming
  - Operation System
  - Artificial Intelligence
  - Probability and Statics
  - Object-Oriented Programming



- and Start at 5/21/2107 forth blog with Github [pages](https://pages.github.com).
