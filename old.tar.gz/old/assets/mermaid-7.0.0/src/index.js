/**
 * Created by knut on 2015-06-06.
 */
module.exports.mermaid = require('./mermaid.js');
module.exports.mermaidAPI = require('./mermaidAPI.js');