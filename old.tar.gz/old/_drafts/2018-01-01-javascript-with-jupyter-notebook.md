---
layout: post
title: "JavaScript with jupyter notebook"
description: ""
date: 2018-01-01
tags: jupyter,java script
comments: true
---



## Java Script with Jupyter Notebook

#### 1. Install

```powershell
brew install pkg-config node zeromq
pip install --upgrade pyzmq jupyter
npm install -g ijavascript
ijsinstall
```

