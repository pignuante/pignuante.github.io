/**
 * Created by knut on 15-03-07.
 */
define('simple',function(){
   var simple = {
       data:'info'
   };
   return simple;
});